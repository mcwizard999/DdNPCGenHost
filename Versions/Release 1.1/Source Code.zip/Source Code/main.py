from NPCClass import NPC
import saveNPCs
import loadNPCs
import generateRandomNPC
from tkinter import *
from PIL import Image, ImageTk
from getLocalFile import *

def loadButtonFunction():
    # loadButton.config(image = pressedLoadButtonImage)
    canvas.itemconfig(loadButton, image = pressedLoadButtonImage)
    canvas.move("loadButton", 2, 2)
    print("Pressed Load Button")
    loadNPCs.load()
    tempList = [str(item) for item in loadNPCs.npcs]
    tempList = "Loaded NPCs: \n"+'\n'.join(tempList)
    editField(NPCList, True, END, tempList)

def releaseLoadButton():
    # loadButton.config(image = loadButtonImage)
    print("Released Load Button")
    canvas.itemconfig(loadButton, image = loadButtonImage)
    canvas.move("loadButton", -2, -2)

def saveButtonFunction():
    # saveButton.config(image = pressedSaveButtonImage)
    canvas.itemconfig(saveButton, image = pressedSaveButtonImage)
    canvas.move("saveButton", 2, 2)
    saveNPCs.save()
    editField(viewNPC, True, END, "Saved NPCs")

def releaseSaveButton():
    # saveButton.config(image = saveButtonImage)
    canvas.itemconfig(saveButton, image = saveButtonImage)
    canvas.move("saveButton", -2, -2)


def createRandomButtonFunction():
    global tempNPC
    canvas.itemconfig(createRandomButton, image = pressedCreateRandomButtonImage)
    canvas.move("createRandomButton", 2, 2)
    tempNPC = generateRandomNPC.addRandomNPC()
    changeViewNPC = "Random NPC: \n"+str(tempNPC)+"\n"+tempNPC.getDetails()
    editField(viewNPC, True, END, changeViewNPC)

def releaseCreateRandomButton():
    canvas.itemconfig(createRandomButton, image = createRandomButtomImage)
    canvas.move("createRandomButton", -2, -2)

def keepButtonFunction():
    global tempNPC
    canvas.itemconfig(keepButton, image = pressedKeepNPCButtonImage)
    canvas.move("keepButton", 2, 2)
    try:
        if tempNPC != None:
            loadNPCs.npcs.append(tempNPC)
            editField(viewNPC, True, END, "Added NPC to loaded NPCs")

            tempList = [str(item) for item in loadNPCs.npcs]
            tempList = "Loaded NPCs: \n"+'\n'.join(tempList)
            editField(NPCList, True, END, tempList)

        tempNPC = None
    except:
        editField(viewNPC, True, END, "No NPC selected to be kept")

def releaseKeepNPC():
    canvas.itemconfig(keepButton, image = keepButtonImage)
    canvas.move("keepButton", -2, -2)

def viewButtonFunction():
    canvas.itemconfig(viewButton, image = pressedViewNPCButtonImage)
    canvas.move("viewButton", 2, 2)
    tempViewNPC = None
    try:
        getView = int(viewField.get("1.0", "end"))
    except:
        viewField.delete("1.0", "end")
        viewField.insert(END, "Input must be a number", "tag1")
    else:
        try:
            tempViewNPC = loadNPCs.npcs[getView - 1]
        except:
            viewField.delete("1.0", "end")
            viewField.insert(END, f"Input must be between 1 and {len(loadNPCs.npcs)}", "tag1")

    if tempViewNPC != None:
        changeViewNPC = "Random NPC: \n"+str(tempViewNPC)+"\n"+tempViewNPC.getDetails()
        editField(viewNPC, True, END, changeViewNPC)
        viewField.delete("1.0", "end")

def clearViewField(event):
    viewField.delete("1.0", "end")

def releaseViewButton():
    canvas.itemconfig(viewButton, image = viewButtonImage)
    canvas.move("viewButton", -2, -2)

def editField(field:Text, delete:bool, addPoint, input:str):
    field.configure(state=NORMAL)
    if delete:
        field.delete("1.0", "end")
    field.insert(addPoint, input)
    field.configure(state=DISABLED)

def creditsButtonFunction():
    global creditsButton, credits
    canvas.itemconfig(creditsButton, image = pressedCreditsButtonImage)
    canvas.move("creditsButton", 2, 2)

    if credits is not None and credits.winfo_exists():
        credits.lift()
        credits.focus_force()
        return
       
    credits = Toplevel(root, width=500, height=500)
    credits.resizable(False, False)
    credits.wm_title("Credits")

    exitButton = Button(credits, image = exitButtonImage, border = 0, command=credits.destroy, text="Exit")
    exitButton.place(relx=0, rely=0.9)

    creditField = Text(credits, wrap=WORD)
    creditField.place(relx=0.1, rely=0.1, width = 300, height = 300)
    creditField.insert(END, creditsText)
    creditField.configure(state=DISABLED)

    credits.protocol(
        "WM_DELETE_WINDOW",
        lambda: close_settings()
    )

def close_settings():
    global credits
    credits.destroy()
    credits = None

def releaseCreditButton():
    canvas.itemconfig(creditsButton, image = creditsButtonImage)
    canvas.move("creditsButton", -2, -2)

displayNPCs = """Loaded NPCs: \nNone"""
ViewingNPC = """Viewing NPC: None"""
creditsText = """Hi! This project was started by me, Riley, but I didn't finish this alone. 
The good folks on the Game Changers League discord server helped immensely with pronouns (How did I forget It/Its?). 
Additionally, this will eventually be ported to MacOS by @UmuraleFireSeer, so thanks for that!"""

showingCredits = False

tempNPC:NPC
tempViewNPC:NPC
NPCOfTheDay:NPC

# Constants
RED = (255, 0, 0)
WHITE = (255, 255, 255)

root = Tk()

root.title("Riley's NPC Generator")
root.geometry('1300x700')

credits:Toplevel = None

# Background
originalBackgroundImage = Image.open(resource_path("Misc Images/background.png"))
resizeBackgroundImage = originalBackgroundImage.resize((2600, 2600), Image.Resampling.LANCZOS)

# Header
originalHeader = Image.open(resource_path("Misc Images/Heading.png"))
resizeHeader = originalHeader.resize((1000, 73), Image.Resampling.LANCZOS)

# Logo
originalLogo = Image.open(resource_path("Misc Images/Logo.png"))
resizeLogo = originalLogo.resize((280, 356), Image.Resampling.LANCZOS)

# Images
pixel = PhotoImage(width=1, height=1)
backgroundImage = ImageTk.PhotoImage(resizeBackgroundImage)
headerImage = ImageTk.PhotoImage(resizeHeader)
logo = ImageTk.PhotoImage(resizeLogo)
loadButtonImage = ImageTk.PhotoImage(Image.open(resource_path("Button Images/Load Button.png")))
saveButtonImage = ImageTk.PhotoImage(Image.open(resource_path("Button Images/Save Button.png")))
createRandomButtomImage = ImageTk.PhotoImage(Image.open(resource_path("Button Images/Create Random Button.png")))
keepButtonImage = ImageTk.PhotoImage(Image.open(resource_path("Button Images/Keep Button.png")))
viewButtonImage = ImageTk.PhotoImage(Image.open(resource_path("Button Images/View Button.png")))
creditsButtonImage = ImageTk.PhotoImage(Image.open(resource_path("Button Images/Credits Button.png")))
exitButtonImage = ImageTk.PhotoImage(Image.open(resource_path("Button Images/Exit Button.png")))

# Pressed Buttons
pressedCreditsButtonImage = ImageTk.PhotoImage(Image.open(resource_path("Button Images/Pressed Credits Button.png")))
pressedSaveButtonImage = ImageTk.PhotoImage(Image.open(resource_path("Button Images/Pressed Save Button.png")))
pressedLoadButtonImage = ImageTk.PhotoImage(Image.open(resource_path("Button Images/Pressed Load Button.png")))
pressedCreateRandomButtonImage = ImageTk.PhotoImage(Image.open(resource_path("Button Images/Pressed Create Random Button.png")))
pressedKeepNPCButtonImage = ImageTk.PhotoImage(Image.open(resource_path("Button Images/Pressed Keep NPC Button.png")))
pressedViewNPCButtonImage = ImageTk.PhotoImage(Image.open(resource_path("Button Images/Pressed View NPC Button.png")))

canvas = Canvas(root, width = 1300, height = 750, bg = "blue")
canvas.pack()

# Button Variables
BUTTON_OFFSET = 110
BUTTON_GAP = 50

# Background
canvas.create_image(1, 1, image = backgroundImage)

# Images
canvas.create_image(650, 75, image = headerImage)
canvas.create_image(470, 525, image = logo)

NPCList = Text(root, wrap=WORD)
NPCList.place(relx=1, rely=0.2, anchor=NE, width=500)
NPCList.insert(END, displayNPCs)
NPCList.configure(state=DISABLED)

# Load Button Code
loadButton = canvas.create_image(80, BUTTON_OFFSET + BUTTON_GAP, image = loadButtonImage, tag = "loadButton")
canvas.tag_bind("loadButton", "<Button-1>", lambda e: loadButtonFunction())
canvas.tag_bind("loadButton", "<ButtonRelease-1>", lambda e: releaseLoadButton())

viewNPC = Text(root, wrap=WORD)
viewNPC.place(relx=0.6, rely=0.2, anchor=NE, width=500, height=150)
viewNPC.insert(END, ViewingNPC)
viewNPC.configure(state=DISABLED)

# Save Button Code
saveButton = canvas.create_image(80, BUTTON_OFFSET + BUTTON_GAP * 2, image = saveButtonImage, tag = "saveButton")
canvas.tag_bind("saveButton", "<Button-1>", lambda e: saveButtonFunction())
canvas.tag_bind("saveButton", "<ButtonRelease-1>", lambda e: releaseSaveButton())

# Random Button Code
createRandomButton = canvas.create_image(80, BUTTON_OFFSET + BUTTON_GAP * 3, image = createRandomButtomImage, tag = "createRandomButton")
canvas.tag_bind("createRandomButton", "<Button-1>", lambda e: createRandomButtonFunction())
canvas.tag_bind("createRandomButton", "<ButtonRelease-1>", lambda e: releaseCreateRandomButton())

# Keep Button Code
keepButton = canvas.create_image(80, BUTTON_OFFSET + BUTTON_GAP * 4, image = keepButtonImage, tag = "keepButton")
canvas.tag_bind("keepButton", "<Button-1>", lambda e: keepButtonFunction())
canvas.tag_bind("keepButton", "<ButtonRelease-1>", lambda e: releaseKeepNPC())

# View Button Code
viewButton = canvas.create_image(80, BUTTON_OFFSET + BUTTON_GAP * 5, image = viewButtonImage, tag = "viewButton")
canvas.tag_bind("viewButton", "<Button-1>", lambda e: viewButtonFunction())
canvas.tag_bind("viewButton", "<ButtonRelease-1>", lambda e: releaseViewButton())

viewField = Text(root)
viewField.tag_config("tag1", foreground = "gray", underline = False)
viewField.tag_bind("tag1", "<Button-1>", clearViewField)
viewField.place(relx=0.208, rely=0.44, width=100, height=40)

# Credits Button Code
creditsButton = canvas.create_image(80, 700, image = creditsButtonImage, tag = "creditsButton")
canvas.tag_bind("creditsButton", "<Button-1>", lambda e: creditsButtonFunction())
canvas.tag_bind("creditsButton", "<ButtonRelease-1>", lambda e: releaseCreditButton())

root.mainloop()