import tkinter as tk
import tkinter.font

# You must initialize Tk before using the font functions
root = tk.Tk()

# Get and print all available font families
for family in sorted(tkinter.font.families()):
    print(family)

# Keep the window open temporarily to prevent the script from exiting immediately
# This is required for Tkinter to properly initialize the font system
root.destroy()