from dataclasses import dataclass

@dataclass
class NPC:
    # Quick Refrence
    name: str
    lastName: str
    pronouns: str

    # Extra Details
    species: str
    npcClass: str
    alignment: str
    quirk: str
    feature: str

    # Stats
    strength: int = 10
    dexterity: int = 10
    constitution: int = 10
    intelligence: int = 10
    wisdom: int = 10
    charisma: int = 10

    def __str__(self):
        return f"{self.name} {self.lastName} ({self.pronouns}) - {self.species} - {self.npcClass} ({self.alignment})"
    def getDetails(self):
        return f"Strength: {self.strength}, Dexterity: {self.dexterity}, Constitution: {self.constitution}, Intelligence: {self.intelligence}, Wisdom: {self.wisdom}, Charisma: {self.charisma}, Detail: {self.quirk}, Feature: {self.feature}"