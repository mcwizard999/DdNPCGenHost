import json
from dataclasses import asdict
from loadNPCs import npcs
from getLocalFile import *
import os
import sys
import shutil

def ensureJsonWriteable():
    bundled = resource_path("npcs.json")
    writable = exe_path("npcs.json")

    if not os.path.exists(writable):
        shutil.copy(bundled, writable)

    return writable

def save():
    path = ensureJsonWriteable()
    with open(path, "w") as f:
        json.dump([asdict(npc) for npc in npcs], f, indent=4)
    return