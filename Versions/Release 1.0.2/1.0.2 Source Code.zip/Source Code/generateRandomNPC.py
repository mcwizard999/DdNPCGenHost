import loadNPCs
import NPCClass
import json
from getLocalFile import resource_path
import random

# Load Pronouns
with open(resource_path("NPC Data/pronouns.json")) as f:
    data = json.load(f)
pronouns = [str(pronounData) for pronounData in data]
pronounMax = len(pronouns) - 1

# Load Classes
with open(resource_path("NPC Data/npcClass.json")) as f:
    data = json.load(f)
npcClasses = [str(npcClassData) for npcClassData in data]
npcClassMax = len(npcClasses) - 1

# Load Species
with open(resource_path("NPC Data/species.json")) as f:
    data = json.load(f)
species = [str(speciesData) for speciesData in data]
speciesMax = len(species) - 1

# Load Aligments
with open(resource_path("NPC Data/alignment.json")) as f:
    data = json.load(f)
alignments = [str(alignmentData) for alignmentData in data]
aligmentMax = len(alignments) - 1

# Load Names
with open(resource_path("NPC Data/name.json")) as f:
    data = json.load(f)
names = [str(nameData) for nameData in data]
nameMax = len(names) - 1

# Load Last Names
with open(resource_path("NPC Data/lastName.json")) as f:
    data = json.load(f)
lastNames = [str(lastNameData) for lastNameData in data]
lastNameMax = len(lastNames) - 1

# Load Quirks
with open(resource_path("NPC Data/detail.json")) as f:
    data = json.load(f)
details = [str(detailData) for detailData in data]
detailMax = len(details) - 1

# Load Features
with open(resource_path("NPC Data/feature.json")) as f:
    data = json.load(f)
features = [str(featureData) for featureData in data]
featureMax = len(features) - 1

def statRoll(diceRolled:int = 4, sides:int = 6, drops:int = 1, reroll1:bool = False):
    rolledList = []
    bonusReroll = 0
    if reroll1 == True:
        bonusReroll = 1

    for i in range(diceRolled):
        rolledList.append(random.randint(1+bonusReroll, sides))
    
    rolledList.sort()
    for i in range(drops):
        rolledList.pop(0)

    returnNumber = 0
    for i in range(3):
        returnNumber += rolledList[i]

    return returnNumber

def initFeatures(inputNPC:NPCClass.NPC, checkFeature:str):
    match checkFeature:
        case "Strong":
            higherScore = statRoll(6, 6, 2, True)
            if inputNPC.strength < higherScore:
                inputNPC.strength = higherScore
        case "Weak":
            lowerScore = statRoll(6, 4, 2, True)
            if inputNPC.strength > lowerScore:
                inputNPC.strength = lowerScore
        case "Lithe":
            higherScore = statRoll(6, 6, 2, True)
            if inputNPC.dexterity < higherScore:
                inputNPC.dexterity = higherScore
        case "Clumsy":
            lowerScore = statRoll(6, 4, 2, True)
            if inputNPC.dexterity > lowerScore:
                inputNPC.dexterity = lowerScore
        case "Hearty":
            higherScore = statRoll(6, 6, 2, True)
            if inputNPC.constitution < higherScore:
                inputNPC.constitution = higherScore
        case "Fragile":
            lowerScore = statRoll(6, 4, 2, True)
            if inputNPC.constitution > lowerScore:
                inputNPC.constitution = lowerScore
        case "Logical":
            higherScore = statRoll(6, 6, 2, True)
            if inputNPC.constitution < higherScore:
                inputNPC.constitution = higherScore
        case "Illogical":
            lowerScore = statRoll(6, 4, 2, True)
            if inputNPC.intelligence > lowerScore:
                inputNPC.intelligence = lowerScore
        case "Wary":
            higherScore = statRoll(6, 6, 2, True)
            if inputNPC.wisdom < higherScore:
                inputNPC.wisdom = higherScore
        case "Rash":
            lowerScore = statRoll(6, 4, 2, True)
            if inputNPC.wisdom > lowerScore:
                inputNPC.wisdom = lowerScore
        case "Charming":
            higherScore = statRoll(6, 6, 2, True)
            if inputNPC.charisma < higherScore:
                inputNPC.charisma = higherScore
        case "Humorless":
            lowerScore = statRoll(6, 4, 2, True)
            if inputNPC.charisma > lowerScore:
                inputNPC.charisma = lowerScore
        case "Boring":
            inputNPC.lastName += " the boring"
        case "Multi Species":
            species1 = species[random.randint(0, speciesMax)]
            species2 = species[random.randint(0, speciesMax)]
            while species1 == species2:
                species2 = species[random.randint(0, speciesMax)]
            inputNPC.species = f"{species1} / {species2}"
        case "Multi Class":
            class1 = npcClasses[random.randint(0, npcClassMax)]
            class2 = npcClasses[random.randint(0, npcClassMax)]
            while class1 == class2:
                class2 = npcClasses[random.randint(0, npcClassMax)]
            inputNPC.npcClass = f"{class1} / {class2}"
        case "Multi Feature":
            doubleFeatures = [features[random.randint(0, featureMax - 1)], ""]
            validFeatures = False
            while validFeatures == False:
                validFeatures = True
                doubleFeatures[1] = features[random.randint(0, featureMax - 1)]
                if doubleFeatures[0] == doubleFeatures[1]:
                    print("Features are the same")
                    validFeatures = False
                if doubleFeatures.__contains__("Strong") and doubleFeatures.__contains__("Weak"):
                    print("Set both strong and weak")
                    validFeatures = False
                if doubleFeatures.__contains__("Lithe") and doubleFeatures.__contains__("Clumsy"):
                    print("Set both lithe and clumsy")
                    validFeatures = False
                if doubleFeatures.__contains__("Hearty") and doubleFeatures.__contains__("Fragile"):
                    print("Set both hearty and fragile")
                    validFeatures = False
                if doubleFeatures.__contains__("Logical") and doubleFeatures.__contains__("Illogical"):
                    print("Set both logical and illogical")
                    validFeatures = False
                if doubleFeatures.__contains__("Wary") and doubleFeatures.__contains__("Rash"):
                    print("Set both wary and rash")
                    validFeatures = False
                if doubleFeatures.__contains__("Charming") and doubleFeatures.__contains__("Humorless"):
                    print("Set both lithe and clumsy")
                    validFeatures = False

            initFeatures(inputNPC, doubleFeatures[0])
            initFeatures(inputNPC, doubleFeatures[1])
            inputNPC.feature = f"Multi Feature ({doubleFeatures[0]} / {doubleFeatures[1]})"
        case _:
            print("feature not implemented yet")
    
    return inputNPC

def addRandomNPC(randomSeed = 0):
    tempName = names[random.randint(0, nameMax)]
    tempLastName = lastNames[random.randint(0, lastNameMax)]
    tempPronouns = pronouns[random.randint(0, pronounMax)]
    tempSpecies = species[random.randint(0, speciesMax)]
    tempNpcClass = npcClasses[random.randint(0, npcClassMax)]
    tempAlignment = alignments[random.randint(0, aligmentMax)]
    tempQuirks = details[random.randint(0, detailMax)]
    tempFeature = features[random.randint(0, featureMax)]

    stats = [statRoll(), statRoll(), statRoll(), statRoll(), statRoll(), statRoll()]
    addNPC = NPCClass.NPC(tempName, tempLastName, tempPronouns, tempSpecies, tempNpcClass, tempAlignment, tempQuirks, tempFeature, stats[0], stats[1], stats[2], stats[3], stats[4], stats[5])
    initFeatures(addNPC, addNPC.feature)

    return addNPC