from NPCClass import NPC
import json
from getLocalFile import *
import os
import sys
import shutil

def ensureJsonWriteable():
    bundled = resource_path("npcs.json")
    writable = exe_path("npcs.json")

    if not os.path.exists(writable):
        shutil.copy(bundled, writable)

    return writable

npcs = [
    NPC("Temp", "Dan", "Any/All", "Dragonborn", "Fighter", "True Neutral", "No Gusto", "NAN")
]

npcs.clear()

def load():
    global npcs
    path = ensureJsonWriteable()
    with open(path) as f:
        data = json.load(f)

    npcs = [NPC(**npc_data) for npc_data in data]