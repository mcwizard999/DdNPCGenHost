from NPCClass import NPC
import saveNPCs
import loadNPCs
import generateRandomNPC
from tkinter import *


def loadButtonFunction():
    loadNPCs.load()
    tempList = [str(item) for item in loadNPCs.npcs]
    tempList = "Loaded NPCs: \n"+'\n'.join(tempList)
    editField(NPCList, True, END, tempList)

def saveButtonFunction():
    saveNPCs.save()
    editField(viewNPC, True, END, "Saved NPCs")


def createRandomButtonFunction():
    global tempNPC
    tempNPC = generateRandomNPC.addRandomNPC()
    changeViewNPC = "Random NPC: \n"+str(tempNPC)+"\n"+tempNPC.getDetails()
    editField(viewNPC, True, END, changeViewNPC)

def keepButtonFunction():
    global tempNPC
    try:
        loadNPCs.npcs.append(tempNPC)
        editField(viewNPC, True, END, "Added NPC to loaded NPCs")

        tempList = [str(item) for item in loadNPCs.npcs]
        tempList = "Loaded NPCs: \n"+'\n'.join(tempList)
        editField(NPCList, True, END, tempList)
        tempNPC = None
    except:
        editField(viewNPC, True, END, "No NPC selected to be kept")

def viewButtonFunction():
    tempViewNPC = None
    try:
        getView = int(viewField.get("1.0", "end"))
    except:
        viewField.delete("1.0", "end")
        viewField.insert(END, "Input must be a number")
    else:
        try:
            tempViewNPC = loadNPCs.npcs[getView - 1]
        except:
            viewField.delete("1.0", "end")
            viewField.insert(END, f"Input must be between 1 and {len(loadNPCs.npcs)}")

    if tempViewNPC != None:
        changeViewNPC = "Random NPC: \n"+str(tempViewNPC)+"\n"+tempViewNPC.getDetails()
        editField(viewNPC, True, END, changeViewNPC)
        viewField.delete("1.0", "end")

def editField(field:Text, delete:bool, addPoint, input:str):
    field.configure(state=NORMAL)
    if delete:
        field.delete("1.0", "end")
    field.insert(addPoint, input)
    field.configure(state=DISABLED)

def creditsButtonFunction():
    global showingCredits
    if not showingCredits:
        showingCredits = True

        credits = Toplevel(width=500, height=500)
        credits.resizable(False, False)
        credits.wm_title("Credits")
        credits.protocol("WM_DELETE_WINDOW", closeCreditWindow)

        exitButton = Button(credits, width=20, height=2, command=credits.destroy, text="Exit")
        exitButton.place(relx=0, rely=0.9)

        creditField = Text(credits, wrap=WORD)
        creditField.place(relx=0.1, rely=0.1, width = 300, height = 300)
        creditField.insert(END, creditsText)
        creditField.configure(state=DISABLED)

def closeCreditWindow():
    global showingCredits
    showingCredits = False

displayNPCs = """Loaded NPCs: \nNone"""
ViewingNPC = """Viewing NPC: None"""
creditsText = """Hi! This project was started by me, Riley, but I didn't finish this alone. 
The good folks on the Game Changers League discord server helped immensely with pronouns (How did I forget It/Its?). 
Additionally, this will eventually be ported to MacOS by @UmuraleFireSeer, so thanks for that!"""

showingCredits = False

tempNPC:NPC
tempViewNPC:NPC
NPCOfTheDay:NPC

root = Tk()

root.title("Riley's NPC Generator")
root.geometry('500x500')

title = Label(root, text="Welcome to Riley's NPC Generator!", font=("Comic Sans MS", 16, "bold"))
title.place(relx=0.5, anchor=N)

NPCList = Text(root, wrap=WORD)
NPCList.place(relx=1, rely=0.1, anchor=NE, width=500)
NPCList.insert(END, displayNPCs)
NPCList.configure(state=DISABLED)

loadButton = Button(root, text="Load", width=20, height=2, command=loadButtonFunction)
loadButton.place(relx=0, rely=0.1)

viewNPC = Text(root, wrap=WORD)
viewNPC.place(relx=0.6, rely=0.1, anchor=NE, width=500, height=150)
viewNPC.insert(END, ViewingNPC)
viewNPC.configure(state=DISABLED)

saveButton = Button(root, text="Save", width=20, height=2, command=saveButtonFunction)
saveButton.place(relx=0, rely=0.16)

createRandomButton = Button(root, text="Create Random", width=20, height=2, command=createRandomButtonFunction)
createRandomButton.place(relx=0, rely=0.22)

keepButton = Button(root, text="Keep NPC", width=20, height=2, command=keepButtonFunction)
keepButton.place(relx=0, rely=0.28)

viewButton = Button(root, text="View NPC", width=20, height=2, command=viewButtonFunction)
viewButton.place(relx=0, rely=0.34)

viewField = Text(root)
viewField.place(relx=0.2, rely=0.34, width=100, height=40)

creditsButton = Button(root, text="credits", width=20, height=2, command=creditsButtonFunction)
creditsButton.place(relx=0, rely=0.95)

root.mainloop()